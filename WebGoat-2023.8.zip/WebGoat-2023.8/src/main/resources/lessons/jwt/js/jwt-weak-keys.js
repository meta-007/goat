$(document).ready(
		function(){
				$("#secrettoken").load('JWT/secret/gettoken');
		}
	);